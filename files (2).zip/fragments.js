// ── 宇宙碎片 FRAGMENTS ──
// 低壓力共鳴互動系統

const FRAG_TTL = 2 * 60 * 60 * 1000; // 2 hours in ms

const EMO_COLORS = {
  family: '#ff8a80', study: '#82b1ff', love: '#ff80ab',
  friend: '#69f0ae', work: '#ffd740', self: '#ea80fc', other: '#b0bec5'
};

let fragCanvas, fragCtx;
let fragBgStars = [];
let fragUnsubscribe = null;
let fragMyReacted = new Set(); // fragment ids I already reacted to
let fragComposeOpen = false;

// ── OPEN / CLOSE ──
function openFragments() {
  document.getElementById('view-fragments').style.display = 'block';
  if (!fragCanvas) initFragCanvas();
  loadFragments();
  listenFragments();
  requestAnimationFrame(fragLoop);
}

function closeFragments() {
  document.getElementById('view-fragments').style.display = 'none';
  if (fragUnsubscribe) { fragUnsubscribe(); fragUnsubscribe = null; }
}

// ── CANVAS STARFIELD ──
function initFragCanvas() {
  fragCanvas = document.getElementById('frag-canvas');
  fragCtx = fragCanvas.getContext('2d');
  fragCanvas.width = window.innerWidth;
  fragCanvas.height = window.innerHeight;
  window.addEventListener('resize', () => {
    fragCanvas.width = window.innerWidth;
    fragCanvas.height = window.innerHeight;
    initFragStars();
  });
  initFragStars();
}

function initFragStars() {
  const W = fragCanvas.width, H = fragCanvas.height;
  fragBgStars = [];
  for (let i = 0; i < 180; i++) {
    fragBgStars.push({
      x: Math.random() * W, y: Math.random() * H,
      r: Math.random() * 1.1 + 0.15,
      phase: Math.random() * Math.PI * 2,
      speed: Math.random() * 0.006 + 0.001,
      hue: [240, 280, 310, 200][Math.floor(Math.random() * 4)]
    });
  }
}

function fragLoop() {
  if (document.getElementById('view-fragments').style.display === 'none') return;
  requestAnimationFrame(fragLoop);

  const W = fragCanvas.width, H = fragCanvas.height;
  const ctx = fragCtx;

  // Deep space background
  const bg = ctx.createLinearGradient(0, 0, 0, H);
  bg.addColorStop(0, '#08081a');
  bg.addColorStop(0.5, '#0a0816');
  bg.addColorStop(1, '#080812');
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, W, H);

  // Soft nebula
  const t = Date.now() / 12000;
  const nebs = [
    [W * 0.2, H * 0.3, W * 0.4, 'rgba(140,80,220,0.04)'],
    [W * 0.8, H * 0.6, W * 0.35, 'rgba(220,100,160,0.03)'],
    [W * 0.5, H * 0.8, W * 0.3, 'rgba(80,120,220,0.035)'],
  ];
  nebs.forEach(([nx, ny, nr, nc], i) => {
    const ox = Math.sin(t + i) * 20, oy = Math.cos(t + i * 1.4) * 15;
    const g = ctx.createRadialGradient(nx + ox, ny + oy, 0, nx + ox, ny + oy, nr);
    g.addColorStop(0, nc); g.addColorStop(1, 'transparent');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
  });

  // Stars
  fragBgStars.forEach(s => {
    s.phase += s.speed;
    const b = 0.2 + 0.5 * (0.5 + 0.5 * Math.sin(s.phase));
    ctx.beginPath();
    ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
    ctx.fillStyle = `hsla(${s.hue},60%,90%,${b})`;
    ctx.fill();
  });
}

// ── LOAD & LISTEN ──
async function loadFragments() {
  const container = document.getElementById('frag-bubbles');
  container.innerHTML = '';

  const cutoff = new Date(Date.now() - FRAG_TTL);
  const snap = await db.collection('fragments')
    .where('ts', '>', cutoff)
    .orderBy('ts', 'desc')
    .limit(20)
    .get();

  const docs = snap.docs;
  const empty = document.getElementById('frag-empty');
  empty.style.display = docs.length === 0 ? 'flex' : 'none';

  docs.forEach((doc, i) => renderFragment(doc.id, doc.data(), i, docs.length));
}

function listenFragments() {
  const cutoff = new Date(Date.now() - FRAG_TTL);
  fragUnsubscribe = db.collection('fragments')
    .where('ts', '>', cutoff)
    .orderBy('ts', 'desc')
    .onSnapshot(snap => {
      snap.docChanges().forEach(ch => {
        if (ch.type === 'added') {
          const existing = document.getElementById('frag-' + ch.doc.id);
          if (!existing) {
            const count = document.querySelectorAll('.frag-bubble').length;
            renderFragment(ch.doc.id, ch.doc.data(), 0, count + 1);
            document.getElementById('frag-empty').style.display = 'none';
          }
        }
        if (ch.type === 'removed') {
          const el = document.getElementById('frag-' + ch.doc.id);
          if (el) { el.style.opacity = '0'; el.style.transition = 'opacity 2s'; setTimeout(() => el.remove(), 2000); }
        }
      });
    });
}

function renderFragment(id, data, index, total) {
  const container = document.getElementById('frag-bubbles');
  const W = window.innerWidth, H = window.innerHeight;

  const el = document.createElement('div');
  el.className = 'frag-bubble';
  el.id = 'frag-' + id;

  // Position: scatter across the viewport with some structure
  const cols = Math.min(3, total);
  const col = index % cols;
  const row = Math.floor(index / cols);
  const baseX = (W / (cols + 1)) * (col + 1) - 130 + (Math.random() - 0.5) * 60;
  const baseY = 100 + row * 220 + (Math.random() - 0.5) * 40;

  el.style.cssText = `
    left: ${Math.max(10, Math.min(W - 280, baseX))}px;
    top: ${Math.max(80, Math.min(H - 250, baseY))}px;
    animation-duration: ${8 + Math.random() * 6}s;
    animation-delay: -${Math.random() * 8}s;
    opacity: 0;
    transition: opacity 1.2s ease;
  `;

  const emoColor = EMO_COLORS[data.emotion] || 'rgba(255,255,255,0.3)';
  const alreadyReacted = fragMyReacted.has(id) || data.fromUid === myUid;
  const timeStr = formatFragTime(data.ts?.seconds);

  el.innerHTML = `
    <div class="frag-text">${escapeHtml(data.text)}</div>
    <div class="frag-time">
      ${data.emotion ? `<span class="frag-emotion-dot" style="background:${emoColor}"></span>` : ''}
      ${timeStr}
    </div>
    <div class="frag-actions">
      <button class="frag-btn resonate ${alreadyReacted ? 'done' : ''}" onclick="reactToFrag('${id}','resonate',this)">
        我也是
      </button>
      <button class="frag-btn accompany ${alreadyReacted ? 'done' : ''}" onclick="reactToFrag('${id}','accompany',this)">
        陪你一下
      </button>
    </div>
  `;

  // If I wrote this, show differently
  if (data.fromUid === myUid) {
    el.style.borderColor = 'rgba(200,160,255,0.2)';
    const actions = el.querySelector('.frag-actions');
    actions.innerHTML = `<div style="font-size:11px;color:rgba(255,255,255,.2);padding:6px 0;text-align:center;width:100%;">你的碎片</div>`;
  }

  container.appendChild(el);

  // Fade in after short delay
  requestAnimationFrame(() => {
    setTimeout(() => { el.style.opacity = '1'; }, 100 + index * 150);
  });
}

// ── REACT ──
async function reactToFrag(fragId, type, btn) {
  if (fragMyReacted.has(fragId)) return;
  fragMyReacted.add(fragId);

  // Disable both buttons
  const bubble = document.getElementById('frag-' + fragId);
  if (!bubble) return;
  bubble.querySelectorAll('.frag-btn').forEach(b => b.classList.add('done'));
  bubble.classList.add('resonated');

  // Glow animation
  bubble.classList.add('glow-pulse');
  setTimeout(() => bubble.classList.remove('glow-pulse'), 1200);

  // Save reaction
  await db.collection('fragments').doc(fragId).update({
    [type === 'resonate' ? 'resonateCount' : 'accompanyCount']:
      firebase.firestore.FieldValue.increment(1)
  });

  // Notify fragment author (silent - no toast, just a light in their space)
  const fragSnap = await db.collection('fragments').doc(fragId).get();
  if (fragSnap.exists) {
    const fragData = fragSnap.data();
    if (fragData.fromUid !== myUid) {
      await db.collection('fragmentReactions').add({
        to: fragData.fromUid,
        type,
        ts: firebase.firestore.FieldValue.serverTimestamp()
      });
    }
  }

  // Subtle confirmation
  const label = type === 'resonate' ? '你讓他知道不孤單了' : '你正在靠近那顆靈魂';
  showFragFeedback(label);
}

function showFragFeedback(text) {
  const el = document.createElement('div');
  el.style.cssText = `
    position:fixed;bottom:120px;left:50%;transform:translateX(-50%);
    background:rgba(15,15,34,.9);border:1px solid rgba(200,160,255,.2);
    border-radius:20px;padding:10px 20px;font-size:12px;
    color:rgba(200,160,255,.8);font-weight:600;z-index:700;
    opacity:0;transition:opacity .4s;letter-spacing:.3px;
    font-family:'Outfit',sans-serif;pointer-events:none;
    white-space:nowrap;
  `;
  el.textContent = text;
  document.body.appendChild(el);
  requestAnimationFrame(() => { el.style.opacity = '1'; });
  setTimeout(() => { el.style.opacity = '0'; setTimeout(() => el.remove(), 500); }, 2500);
}

// Listen for reactions to my fragments
function listenFragmentReactions() {
  db.collection('fragmentReactions')
    .where('to', '==', myUid)
    .where('ts', '>', new Date(Date.now() - 5000))
    .onSnapshot(snap => {
      snap.docChanges().forEach(ch => {
        if (ch.type === 'added') {
          // Trigger light glow on my star (in space)
          if (typeof lightWaves !== 'undefined') {
            lightWaves.push({ x: myX, y: myY, r: 10, life: 1 });
          }
        }
      });
    });
}

// ── COMPOSE ──
function openFragCompose() {
  document.getElementById('frag-compose').classList.add('open');
  fragComposeOpen = true;
  setTimeout(() => document.getElementById('frag-textarea').focus(), 400);
}

function closeFragCompose() {
  document.getElementById('frag-compose').classList.remove('open');
  fragComposeOpen = false;
  document.getElementById('frag-textarea').value = '';
}

async function releaseFragment() {
  const text = document.getElementById('frag-textarea').value.trim();
  if (!text) return;
  if (text.length < 2) return;

  closeFragCompose();

  // Save to Firestore
  await db.collection('fragments').add({
    text,
    fromUid: myUid,
    emotion: myData.emotion || '',
    ts: firebase.firestore.FieldValue.serverTimestamp(),
    resonateCount: 0,
    accompanyCount: 0
  });

  // Show released confirmation
  showReleasedConfirmation();
}

function showReleasedConfirmation() {
  const el = document.getElementById('frag-released');
  el.classList.add('show');
  setTimeout(() => el.classList.remove('show'), 3000);
}

// ── UTILS ──
function formatFragTime(seconds) {
  if (!seconds) return '剛剛';
  const diff = Math.floor((Date.now() / 1000) - seconds);
  if (diff < 60) return '剛剛';
  if (diff < 3600) return Math.floor(diff / 60) + ' 分鐘前';
  if (diff < 7200) return '1 小時前';
  return Math.floor(diff / 3600) + ' 小時前';
}

function escapeHtml(text) {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;')
    .replace(/\n/g, '<br>');
}

// Close compose on backdrop tap
document.addEventListener('click', e => {
  if (fragComposeOpen && e.target.id === 'view-fragments') closeFragCompose();
});
